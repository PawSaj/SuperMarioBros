package com.project.mario.enums;

/**
 * Enumeraty oblicza (stron� w kt�r� zwr�cony jest obiekt).
 * 
 * @author Pawe� Sajn�g
 *
 */
public enum Facing {
	left, right;
}
